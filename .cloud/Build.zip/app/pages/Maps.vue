<template>
	<Page>
		<GridLayout>
		<MapView  />

		</GridLayout>
	</Page>
</template>

<script>
// import { MapViewBase } from 'nativescript-google-maps-sdk/map-view-common';
import { Position, Marker } from "nativescript-google-maps-sdk";

export default {
	data () {
		return {
			latitude:  34.019586,
			longitude: 74.801348,
			zoom: 15,
			minZoom: 0,
			maxZoom: 22,
			bearing: 0,
			tilt: 0,
			padding: [40, 40, 40, 40],
			mapView: null,
		};
	},
	methods: {
		mapReady(args) {
      console.log('map ready')
			this.mapView = args.object
			this.mapView.infoWindowTemplate = `
				<StackLayout orientation="vertical" width="200">
					<Label text="{{title}}" className="title"/>
					<Label text="{{snippet}}" textWrep="true" class="snippet"/>
				</StackLayout>
			`
			const marker = new Marker()
			marker.position = Position.positionFromLatLng(0, 0)
			marker.title = 'Test'
			marker.snippet = 'test'
			marker.userData = {test: 'test'}
			this.mapView.addMarker(marker)
		},
		onMarkerSelect(args) {
			console.log(args.marker)
		}
	}
};
</script>










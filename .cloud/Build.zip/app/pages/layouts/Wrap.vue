<template>
<Page>
    <ActionBar title="Wrap Layout"/>
    <WrapLayout orientation="vertical">
       <Label text="Wrap under construction..."/>
        <Image src="~/images/chart.png" stretch="none" />
        <Button text="Wrap Button" />
    </WrapLayout>
</Page>
</template>
